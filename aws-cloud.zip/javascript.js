document.querySelectorAll('.toggle-button').forEach(button => {
    button.addEventListener('click', () => {
        const description = button.previousElementSibling;
        description.style.display = description.style.display === 'block' ? 'none' : 'block';
        button.textContent = button.textContent === 'More Info' ? 'Less Info' : 'More Info';
    });
});
